java -jar zap.jar org.zaproxy.zap.ZAP $*
